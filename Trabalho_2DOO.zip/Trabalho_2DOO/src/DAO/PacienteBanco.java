/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import model.PacienteModel;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.sql.ResultSet;

public class PacienteBanco {
    public void inserirPacienteBD(PacienteModel paciente){
        String sql = "INSERT INTO PACIENTE(nome, cns, dataNascimento, dataDUM) VALUES(?, ?, ?, ?)";
        Connection connection = null;
        PreparedStatement stmt = null;
        
        try {
            connection = new conexãoDAO().conectorBD();
            stmt = connection.prepareStatement(sql);
            stmt.setString(1, paciente.getNome());
            stmt.setString(2, paciente.getCNS());
            stmt.setDate(3, new java.sql.Date(paciente.getDataNascimento().getTime()));
            stmt.setDate(4, new java.sql.Date(paciente.getDataDUM().getTime()));
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Dados inseridos no banco com sucesso!");
            
        }catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao conectar ao banco");
        }finally{
            try{
               if(stmt != null){
                   stmt.close();
               } 
            }catch(SQLException e){
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Erro ao fechar o stmt");
            }
        }
    }
    public ArrayList<PacienteModel> listarTodosPacientes(){
        Connection conn = null;
        PreparedStatement stmt = null;
        PacienteModel paciente = null;
        ArrayList<PacienteModel> listaPacientes = null;
        ResultSet rs = null;
        
        String sql = "SELECT * FROM PACIENTE";
        
        try {
            conn = new conexãoDAO().conectorBD();
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();
            
            if(rs != null){
                listaPacientes = new ArrayList<>();
                while(rs.next()){
                    paciente = new PacienteModel();
                    paciente.setID(rs.getInt("idusuario"));
                    paciente.setNome(rs.getString("nome"));
                    paciente.setCNS(rs.getString("cns"));
                    paciente.setDataNascimento(rs.getDate("dataNascimento"));
                    paciente.setDataDUM(rs.getDate("dataDUM"));
                    listaPacientes.add(paciente);
                }
            }
            System.out.println("Dados coletados com sucesso!"); 
       } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Erro ao selecionar os dados!");
        }finally{
            try{
               if(stmt != null){
                   stmt.close();
               } 
            }catch(SQLException e){
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Erro ao fechar o stmt");
            }
        }
        
        return listaPacientes;
    }
    
    public ArrayList<PacienteModel> buscarPaciente(String nomeBusca) {
    Connection conn = null;
    PreparedStatement stmt = null;
    ArrayList<PacienteModel> listaPacientes = new ArrayList<>();
    ResultSet rs = null;

    String sql = "SELECT * FROM paciente WHERE nome LIKE ?";

    try {
        conn = new conexãoDAO().conectorBD();
        stmt = conn.prepareStatement(sql);

        // Usando LIKE com % para busca parcial
        stmt.setString(1, "%" + nomeBusca + "%");

        rs = stmt.executeQuery();

        while (rs.next()) {
            PacienteModel paciente = new PacienteModel();
            paciente.setID(rs.getInt("idusuario"));
            paciente.setNome(rs.getString("nome"));
            paciente.setCNS(rs.getString("cns"));
            paciente.setDataNascimento(rs.getDate("dataNascimento"));
            paciente.setDataDUM(rs.getDate("dataDUM"));
            listaPacientes.add(paciente);
        }

        System.out.println("Busca realizada com sucesso!");

    } catch (Exception e) {
        e.printStackTrace();
        System.out.println("Erro ao buscar paciente!");
    } finally {
        try {
            if (stmt != null) {
                stmt.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao fechar o stmt");
        }
    }

    return listaPacientes;
    }
    
    public void excluirPaciente(String nome) {
        String sql = "DELETE FROM paciente WHERE nome = ?";
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = new conexãoDAO().conectorBD();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, nome);
            int linhasAfetadas = stmt.executeUpdate();

            if (linhasAfetadas > 0) {
                JOptionPane.showMessageDialog(null, "Paciente excluido com sucesso!");
                System.out.println("Exclusao realizada com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, "Nenhum paciente com esse nome foi encontrado para exclusão.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao excluir os dados!");
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException sQLException) {
                sQLException.printStackTrace();
            }
        }
    }
        public void alterarPaciente(PacienteModel pacienteAjuste) {
            Connection conn = null;
            PreparedStatement stmt = null;

            String sql = "UPDATE paciente SET cns = ?, dataNascimento = ?, dataDum = ? WHERE nome = ?";
            try {
                conn = new conexãoDAO().conectorBD();
                stmt = conn.prepareStatement(sql);

                stmt.setString(1, pacienteAjuste.getCNS());
                stmt.setDate(2, new java.sql.Date(pacienteAjuste.getDataNascimento().getTime()));
                stmt.setDate(3, new java.sql.Date(pacienteAjuste.getDataDUM().getTime()));
                stmt.setString(4, pacienteAjuste.getNome()); // O nome vai por último para a cláusula WHERE

                stmt.executeUpdate();

                JOptionPane.showMessageDialog(null, "Alteração de registro realizada com sucesso!");

            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Erro ao atualizar os dados!");
            } finally {
                try {
                    if (stmt != null) {
                        stmt.close();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Erro ao fechar o stmt");
                }
                try {
                    if (conn != null) {
                        conn.close();
                    }
                } catch (SQLException sQLException) {
                    sQLException.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Erro ao encerrar a conexão!");
                }
            }
        }
}

