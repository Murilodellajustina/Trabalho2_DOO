/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import DAO.PacienteBanco;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author lidiane
 */
public class PacienteModel {
    private int id;
    private String nome;
    private String CNS;
    private Date DataNascimento;
    private Date DataDUM;

    // construtures
    public PacienteModel() {
    }

    public PacienteModel(String nome, String CNS, Date DataNascimento, Date DataDUM) {
        this.nome = nome;
        this.CNS = CNS;
        this.DataNascimento = DataNascimento;
        this.DataDUM = DataDUM;
    }
    
    //getter e setters
    public int getId() {
        return id;
    }
    public String getNome() {
        return nome;
    }

    public String getCNS() {
        return CNS;
    }

    public Date getDataNascimento() {
        return DataNascimento;
    }

    public Date getDataDUM() {
        return DataDUM;
    }
    
    
    public void setID(int id) {
        this.id = id;
    } 

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setCNS(String CNS) {
        this.CNS = CNS;
    }

    public void setDataNascimento(Date DataNascimento) {
        this.DataNascimento = DataNascimento;
    }

    public void setDataDUM(Date DataDUM) {
        this.DataDUM = DataDUM;
    }

    
    
    public void cadastrarPacienteDAO(PacienteModel paciente){
        PacienteBanco novoPaciente = new PacienteBanco();
        novoPaciente.inserirPacienteBD(paciente);
        System.out.println("Dados enviados para o banco de dados!");
    }
    
    public ArrayList<PacienteModel> listaPacientes(){
        return new PacienteBanco().listarTodosPacientes();
    }
    public ArrayList<PacienteModel> buscaPacientes(){
        return new PacienteBanco().buscarPaciente(nome);
    }
    public void excluirPaciente(String nome) {
        PacienteBanco excluiPaciente = new PacienteBanco();
        excluiPaciente.excluirPaciente(nome);
        System.out.println("Dados excluidos!");
    }
    public void alterarPaciente(PacienteModel pacienteAjuste) {
        PacienteBanco ajustePaciente = new PacienteBanco();
        ajustePaciente.alterarPaciente(pacienteAjuste);
        System.out.println("Dados atualizados!");
    }
    
}