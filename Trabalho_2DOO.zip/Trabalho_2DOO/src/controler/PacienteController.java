/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controler;

/**
 *
 * @author alunolages
 */
import DAO.PacienteBanco;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;
import model.PacienteModel;

public class PacienteController {
    
    public void cadastraPacienteController(String nome, String cns, Date dataNascimento, Date dataDUM){
        if((nome != null && nome.length()>0) && (cns != null && cns.length()>0) && (dataNascimento != null) && (dataDUM != null)){
            PacienteModel novoPaciente = new PacienteModel(nome, cns, dataNascimento, dataDUM);
            novoPaciente.cadastrarPacienteDAO(novoPaciente);
            JOptionPane.showMessageDialog(null, "Paciente Registrado!");
        }else{
            JOptionPane.showMessageDialog(null, "Digite os dados corretamente!");
        }
    }
    
    public ArrayList<PacienteModel> listarPacientesController(){
        PacienteModel Pacientes = new PacienteModel();
        return Pacientes.listaPacientes();
        
    }
    public ArrayList<PacienteModel> buscarPacienteController(String nomeBusca) {
    PacienteBanco banco = new PacienteBanco();
    return banco.buscarPaciente(nomeBusca);
}
    
    public void excluirPaciente(String nome) {
        if ((nome != null)) {
            int i = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja excluir o paciente?");
            if (i == JOptionPane.YES_OPTION) {
                PacienteModel excluiPaciente = new PacienteModel();
                excluiPaciente.excluirPaciente(nome);   
            } else if (i == JOptionPane.NO_OPTION) {
                System.out.println("Clicou em Não");
            } else if (i == JOptionPane.CANCEL_OPTION) {
                System.out.println("Clicou em Cancel");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Informações Incorretas!");
        }
    }
    
    public void alterarPaciente(String nome, String CNS, Date DataNascimento, Date DataDUM) {
    
    if ((nome != null && nome.length() > 0) && (CNS != null && CNS.length() > 0)) {
        PacienteModel alteraPaciente = new PacienteModel(nome, CNS, DataNascimento, DataDUM);
        alteraPaciente.alterarPaciente(alteraPaciente);
    } else {
        JOptionPane.showMessageDialog(null, "Informações Incorretas!");
    }
}
}
