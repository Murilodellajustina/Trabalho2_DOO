/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package view;

/**
 *
 * @author lidiane
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TelaLogin login = new TelaLogin();
        login.setLocationRelativeTo(null); //Seta a posição inicial da janela para o centro da tela.
        login.setVisible(true);
    }
    
}
