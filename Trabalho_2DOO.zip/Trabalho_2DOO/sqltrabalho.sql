create database sqltrabalho;

use sqltrabalho;

create table paciente(
idusuario int not null primary key auto_increment,
nome varchar(100) not null,
cns varchar(20) not null,
dataNascimento date not null,
dataDum date not null
);
DROP TABLE paciente;
SELECT * FROM sqltrabalho.paciente WHERE nome LIKE "Valdirene";
insert into paciente(nome, cns, dataNascimento, dataDUM) values("Valdirene", "706703533051118", '2006-07-13', '2024-08-13');
